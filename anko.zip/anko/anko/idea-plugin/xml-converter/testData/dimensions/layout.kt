linearLayout {
    button.lparams(width = wrapContent, height = wrapContent) {
        leftMargin = dip(0.5f)
        topMargin = dip(1)
        rightMargin = sp(2)
        bottomMargin = px(3)
    }
    button.lparams(width = wrapContent, height = wrapContent)
}