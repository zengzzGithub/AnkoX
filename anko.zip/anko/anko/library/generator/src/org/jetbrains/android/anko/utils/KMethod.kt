package org.jetbrains.android.anko.utils

class KMethod(val name: String, val parameters: List<KVariable>, val returnType: KType)